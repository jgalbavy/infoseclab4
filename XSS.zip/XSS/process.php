<?php 
 
   $uname = $_GET['username'];
   $greeting = "Hello ".$uname;
   echo $greeting;

?>
